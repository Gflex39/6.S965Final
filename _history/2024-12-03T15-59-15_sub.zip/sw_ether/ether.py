from scapy import *
from scapy.layers.l2 import Ether
from scapy.packet import Raw
from scapy.sendrecv import sendp
from time import sleep


frame=Ether(src="00:00:00:00:00:00", dst="be:ef:de:ad:fe:fe", type=46)/Raw("\x11"*46)
sendp(frame, iface="en12")
sleep(1)
frame=Ether(src="00:00:00:00:00:00", dst="be:ef:de:ad:fe:fe", type=46)/Raw("\x01"*46)
sendp(frame,iface="en12")


